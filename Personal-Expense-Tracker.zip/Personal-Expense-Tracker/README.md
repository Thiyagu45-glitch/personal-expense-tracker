# Personal Expense Tracker (Java)

## About
Personal Expense Tracker is a simple Java console application that helps users keep track of everyday spending.

## Features
- Add an expense with a description and amount
- View all recorded expenses
- Calculate total spending
- Delete an expense
- Validate numeric input and reject amounts that are zero or negative

## Technology
- Java
- Scanner
- ArrayList
- Loops, methods, and switch statements

## Requirements
Install Java JDK 8 or newer.

## How to Run
1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Compile the program:

   ```bash
   javac Main.java
   ```

4. Run the program:

   ```bash
   java Main
   ```

## Example
```text
=== Personal Expense Tracker ===
1. Add Expense
2. View Expenses
3. Show Total Spending
4. Delete Expense
5. Exit
Enter your choice: 1
Enter expense description: Lunch
Enter amount: 120
Expense added successfully!
```

## How It Works
The program stores expense descriptions and amounts in two `ArrayList` collections. A menu lets the user add, view, total, or delete expenses.

## Limitation
Expenses are stored in memory and are cleared when the program exits. Saving expenses to a file is a possible future improvement.

## Future Improvements
- Save expenses to a file
- Group expenses by category
- Add monthly spending summaries
- Create a graphical user interface

## Author
Add your name here before submitting.
